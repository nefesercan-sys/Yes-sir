import { geoLd, CLUSTER_ONLINE, BRAND, GBP, ADDRESS, SAME_AS, BUSINESS_ID } from '@/lib/terzi-business'
import type { Metadata } from 'next';
import OnlineSchneiderClient from './OnlineSchneiderClient';

const BASE_URL  = 'https://swaphubs.com';
const SITE_URL  = `${BASE_URL}/de/online-schneiderservice-antalya`;
const PHONE     = '+90 531 898 64 18';
const PHONE_E   = '+905318986418';
const TODAY     = new Date().toISOString().split('T')[0];
const OG_IMG    = `${BASE_URL}/og/terzi-can.jpg`;

// Konyaaltı Hurma ve Liman Şube / Lokasyon Bilgileri (EN sayfasıyla aynı, gerçek işletme verisi)
const GBP1 = {
  name:  BRAND.gbpName,
  addr:  ADDRESS.oneLine,
  maps:  GBP.shareUrl,
  short: GBP.shareUrl,
  embed: GBP.embedUrl,
  review: GBP.reviewUrl,
};

export const metadata: Metadata = {
  metadataBase: new URL(BASE_URL),
  title: 'Online Schneiderservice Antalya — Herren- & Damenschneiderei · Bügelservice',
  description:
    'Online-Schneiderservice mit Sitz in Konyaaltı. Herren- & Damenschneiderei, Bügelservice, Reparaturen, ' +
    'Änderungen, Serienproduktion. Versand in die ganze Türkei. Bestellung per WhatsApp. ☎ ' + PHONE,
  keywords: [
    'Online Schneider Antalya', 'Herrenschneiderei Antalya', 'Damenschneiderei Antalya',
    'Bügelservice Antalya', 'Änderungsschneiderei Antalya', 'Serienproduktion Antalya',
    'Konyaaltı Schneider', 'Online Schneiderservice', 'Schneider Antalya',
  ],
  alternates: {
    canonical: SITE_URL,
    languages: CLUSTER_ONLINE,
  },
  openGraph: {
    title: 'Online Schneiderservice Antalya — Herren- & Damenschneiderei',
    description: 'Herren- & Damenschneiderei, Bügelservice, Reparaturen, Änderungen, Serienproduktion. Versand in die ganze Türkei.',
    url: SITE_URL, siteName: 'Terzi Can', locale: 'de_DE', alternateLocale: ['tr_TR', 'en_US', 'ru_RU'], type: 'website',
    images: [{ url: OG_IMG, width: 1200, height: 630, alt: 'Online Schneiderservice Antalya', type: 'image/jpeg' }],
  },
  robots: {
    index: true, follow: true,
    googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 },
  },
  other: {
    'geo.region': 'TR-07', 'geo.placename': 'Hurma, Konyaaltı, Antalya',
  },
};

const jsonLd = {
  '@context': 'https://schema.org',
  '@graph': [
    {
      '@type': ['LocalBusiness', 'ClothingStore'],
      additionalType: 'https://schema.org/SewingService',
      '@id': BUSINESS_ID,
      name: 'TERZİ Can - Konyaaltı Terzi Ve Ütü Hizmeti',
      alternateName: ['Online Schneiderservice Antalya', 'Terzi Can Antalya', 'Tailor Can Antalya'],
      description:
        'Online-Schneiderservice mit Sitz in Konyaaltı. Herren- und Damenschneiderei, ' +
        'Bügelservice, Reparaturen, Änderungen, individuelles Design und Serienproduktion.',
      url: SITE_URL,
      telephone: PHONE_E,
      priceRange: '₺₺',
      image: OG_IMG,
      hasMap: GBP1.maps,
      address: {
        '@type': 'PostalAddress',
        streetAddress: 'Hurma Mahallesi',
        addressLocality: 'Konyaaltı',
        addressRegion: 'Antalya',
        postalCode: '07130',
        addressCountry: 'TR',
      },
      ...geoLd(),
      openingHoursSpecification: [{
        '@type': 'OpeningHoursSpecification',
        dayOfWeek: ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],
        opens: '08:00', closes: '23:00',
      }],
      sameAs: SAME_AS,
      knowsLanguage: ['tr', 'en', 'ru', 'de'],
    },
    {
      '@type': 'WebPage',
      '@id': `${SITE_URL}#webpage`,
      name: 'Online Schneiderservice Antalya — Herren- & Damenschneiderei · Bügelservice',
      url: SITE_URL, inLanguage: 'de', dateModified: TODAY,
      about: { '@id': BUSINESS_ID },
      breadcrumb: { '@id': `${SITE_URL}#breadcrumb` },
    },
    {
      '@type': 'BreadcrumbList', '@id': `${SITE_URL}#breadcrumb`,
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'SwapHubs', item: BASE_URL },
        { '@type': 'ListItem', position: 2, name: 'Terzi Can', item: `${BASE_URL}/terzi` },
        { '@type': 'ListItem', position: 3, name: 'Online Schneiderservice', item: SITE_URL },
      ],
    },
    {
      '@type': 'FAQPage',
      mainEntity: [
        { '@type': 'Question', name: 'Was kostet ein Herrenanzug in Antalya?',
          acceptedAnswer: { '@type': 'Answer', text: `Ab ₺2.500. Senden Sie Ihre Maße per WhatsApp: ${PHONE}` } },
        { '@type': 'Question', name: 'Wie funktioniert der Online-Schneiderservice?',
          acceptedAnswer: { '@type': 'Answer', text: `Senden Sie ein Referenzfoto und Maße per WhatsApp — wir nähen und versenden es. ${PHONE}` } },
        { '@type': 'Question', name: 'Kommen Sie für den Bügelservice zu meinem Hotel?',
          acceptedAnswer: { '@type': 'Answer', text: `Ja! Kurierabholung und -lieferung zu jedem Hotel in Antalya, am selben Tag. ${PHONE}` } },
        { '@type': 'Question', name: 'Gibt es einen deutschsprachigen Schneider in Antalya?',
          acceptedAnswer: { '@type': 'Answer', text: `Ja! Wir sprechen Deutsch, Englisch und Russisch. WhatsApp: ${PHONE}` } },
        { '@type': 'Question', name: 'Mein Kleid ist gerissen — können Sie es am selben Tag reparieren?',
          acceptedAnswer: { '@type': 'Answer', text: `Ja, die meisten Risse und offenen Nähte werden am selben Tag repariert. Senden Sie ein Foto per WhatsApp für eine sofortige Einschätzung. ${PHONE}` } },
        { '@type': 'Question', name: 'Haben Sie abends oder am Wochenende geöffnet?',
          acceptedAnswer: { '@type': 'Answer', text: `Ja, wir haben täglich von 08:00 bis 23:00 Uhr geöffnet, auch abends und am Wochenende. Schreiben Sie uns auf WhatsApp für einen Termin. ${PHONE}` } },
        { '@type': 'Question', name: 'Kann ich mir ein individuelles Kleid anfertigen lassen?',
          acceptedAnswer: { '@type': 'Answer', text: `Ja, wir fertigen Kleidungsstücke nach Ihren Maßen und Ihrem gewünschten Stil — vom Alltagskleid bis zum Abendkleid. Senden Sie ein Referenzfoto per WhatsApp. ${PHONE}` } },
        { '@type': 'Question', name: 'Nähen Sie mit Naturstoffen wie Baumwolle oder Leinen?',
          acceptedAnswer: { '@type': 'Answer', text: `Ja, wir bieten maßgeschneiderte Kleidung aus 100% Baumwolle und Leinen an. ${PHONE}` } },
      ],
    },
  ],
};

export default function OnlineSchneiderservicePage() {
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <OnlineSchneiderClient
        gbpName1={GBP1.name}
        gbpAddr1={GBP1.addr}
        gbpEmbed1={GBP1.embed}
        gbpMaps1={GBP1.maps}
        gbpShort1={GBP1.short}
        gbpReview1={GBP1.review}
      />
    </>
  );
}
