import type { Metadata } from 'next'

// /ilan-detay eski bir yol; gerçek içerik /ilan/[slug] altında. Kopya içerik oluşmasın.
export const metadata: Metadata = {
  robots: { index: false, follow: true },
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
