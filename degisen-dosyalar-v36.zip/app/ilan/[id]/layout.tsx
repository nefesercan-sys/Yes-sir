import type { Metadata } from 'next'
import { ObjectId } from 'mongodb'
import { getDb } from '@/lib/mongodb'
import { SITE_URL, ldJson } from '@/lib/terzi-business'

// /ilan/[id]/page.tsx bir client component olduğundan title/description/canonical/JSON-LD
// bu layout üzerinden SUNUCUDA üretilir (botlar iskelet HTML yerine gerçek içeriği görür).

type Ilan = {
  _id: ObjectId
  slug?: string
  baslik?: string
  aciklama?: string
  sektorId?: string
  kategoriAd?: string
  sehir?: string
  formData?: { sehir?: string }
  createdAt?: string | Date
  updatedAt?: string | Date
}

async function getIlan(id: string): Promise<Ilan | null> {
  try {
    const db = await getDb()
    const query = ObjectId.isValid(id) ? { $or: [{ _id: new ObjectId(id) }, { slug: id }] } : { slug: id }
    return (await db.collection('ilanlar').findOne(query)) as Ilan | null
  } catch {
    return null
  }
}

const clip = (s: string, n: number) => (s.length > n ? s.slice(0, n - 1).trimEnd() + '…' : s)

export async function generateMetadata({ params }: { params: { id: string } }): Promise<Metadata> {
  const ilan = await getIlan(params.id)
  if (!ilan?.baslik) {
    return { title: 'İlan', robots: { index: false, follow: true } }
  }
  const sehir = ilan.formData?.sehir ?? ilan.sehir ?? ''
  const url = `${SITE_URL}/ilan/${ilan.slug ?? params.id}`
  const title = `${ilan.baslik}${sehir ? ` — ${sehir}` : ''}`
  const description = clip(
    (ilan.aciklama ?? '').replace(/\s+/g, ' ').trim() ||
      `${ilan.baslik}. ${ilan.kategoriAd ?? ''} ${sehir} ilanı. Detaylar ve iletişim için tıklayın.`,
    158,
  )
  return {
    title: { absolute: `${title} | SwapHubs` },
    description,
    alternates: { canonical: url },
    openGraph: { title, description, url, type: 'article', siteName: 'SwapHubs', locale: 'tr_TR' },
    robots: { index: true, follow: true },
  }
}

export default async function IlanLayout({
  children,
  params,
}: {
  children: React.ReactNode
  params: { id: string }
}) {
  const ilan = await getIlan(params.id)
  const sehir = ilan?.formData?.sehir ?? ilan?.sehir
  const ld = ilan?.baslik
    ? {
        '@context': 'https://schema.org',
        '@type': 'Service',
        name: ilan.baslik,
        description: clip((ilan.aciklama ?? '').replace(/\s+/g, ' ').trim(), 300),
        url: `${SITE_URL}/ilan/${ilan.slug ?? params.id}`,
        ...(ilan.kategoriAd ? { serviceType: ilan.kategoriAd } : {}),
        ...(sehir ? { areaServed: { '@type': 'City', name: sehir } } : {}),
        provider: { '@type': 'Organization', name: 'SwapHubs', url: SITE_URL },
      }
    : null
  return (
    <>
      {ld && <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ldJson(ld) }} />}
      {children}
    </>
  )
}
