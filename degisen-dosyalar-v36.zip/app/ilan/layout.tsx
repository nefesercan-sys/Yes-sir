import type { Metadata } from 'next'
import { SITE_URL } from '@/lib/terzi-business'

export const metadata: Metadata = {
  title: { absolute: 'İlanlar | SwapHubs' },
  description: 'SwapHubs hizmet ve ürün ilanları.',
  alternates: { canonical: `${SITE_URL}/ilanlar` },
  robots: { index: false, follow: true },
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
