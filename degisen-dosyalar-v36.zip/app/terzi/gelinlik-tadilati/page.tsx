import type { Metadata } from 'next'
import Link from 'next/link'
import {
  SITE_URL, BRAND, BUSINESS_ID, PHONE, ADDRESS, HOURS, PRICES, GBP, OG_IMAGE,
  waLink, businessRef, breadcrumbLd, ldJson,
} from '@/lib/terzi-business'

const PAGE_URL = `${SITE_URL}/terzi/gelinlik-tadilati`
const TITLE = 'Gelinlik Tadilatı Antalya — Konyaaltı | Terzi Can'
const DESC = `Antalya Konyaaltı gelinlik tadilatı: beden daraltma-genişletme, boy ayarı, askı ve kol düzenleme, korse, dantel onarımı. ${PRICES.weddingDressAlteration} ₺'den başlayan fiyatlar. ${HOURS.text.tr}. WhatsApp: ${PHONE}`

export const metadata: Metadata = {
  title: { absolute: TITLE },
  description: DESC,
  keywords: ['gelinlik tadilatı antalya', 'gelinlik daraltma', 'gelinlik boy kısaltma', 'gelinlik tamiri konyaaltı', 'abiye tadilatı antalya', 'damatlık tadilatı antalya'],
  alternates: { canonical: PAGE_URL },
  openGraph: { title: TITLE, description: DESC, url: PAGE_URL, siteName: BRAND.name, locale: 'tr_TR', type: 'website', images: [{ url: OG_IMAGE, width: 1200, height: 630, alt: 'Gelinlik tadilatı Antalya — Terzi Can' }] },
  robots: { index: true, follow: true, googleBot: { index: true, follow: true, 'max-image-preview': 'large', 'max-snippet': -1 } },
}

const SERVICES: [string, string][] = [
  ['Beden daraltma / genişletme', 'Bel, kalça ve göğüs hattında ölçüye göre ayar; kumaş ve dikiş izi korunur.'],
  ['Boy kısaltma ve etek düzeni', 'Etek boyu, kuyruk ve tül katları gelinlik ayakkabısıyla ölçülerek ayarlanır.'],
  ['Askı, kol ve yaka düzenleme', 'Askı ekleme-çıkarma, kol daraltma, yaka kapatma veya açma.'],
  ['Korse ve fermuar', 'Kırık fermuar değişimi, korse bağcığı ve iç destek tamiri.'],
  ['Dantel, tül ve boncuk onarımı', 'Yırtık, sökük ve dökülen işlemelerin onarımı.'],
  ['Damatlık ve abiye tadilatı', 'Ceket, pantolon ve abiye elbiselerde ölçüye göre ayar.'],
]

const FAQ: [string, string][] = [
  ['Gelinlik tadilatı Antalya\'da ne kadar tutar?', `Gelinlik tadilatı ${PRICES.weddingDressAlteration} ₺'den başlar. Kesin fiyat modele ve yapılacak işleme göre belirlenir; fotoğraf gönderirseniz WhatsApp'tan fiyat veririz.`],
  ['Tadilat kaç günde biter?', 'İşlemin kapsamına göre genellikle birkaç gün sürer; düğün tarihinizi söylerseniz buna göre planlarız.'],
  ['Prova için gelmem gerekir mi?', 'Evet, doğru sonuç için en az bir prova önerilir. Adresimiz Konyaaltı, Hurma Mahallesi. İsterseniz adrese veya otele gelen terzi hizmetimizi de kullanabilirsiniz.'],
  ['Hangi günler açıksınız?', `${HOURS.text.tr}. Pazar dahil her gün hizmet veriyoruz.`],
]

export default function GelinlikTadilatiPage() {
  const ld = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'Service',
        '@id': `${PAGE_URL}#service`,
        name: 'Gelinlik Tadilatı',
        serviceType: 'Gelinlik tadilatı',
        provider: businessRef(),
        areaServed: { '@type': 'City', name: 'Antalya' },
        url: PAGE_URL,
        offers: { '@type': 'Offer', priceCurrency: 'TRY', price: String(PRICES.weddingDressAlteration), priceSpecification: { '@type': 'PriceSpecification', priceCurrency: 'TRY', minPrice: PRICES.weddingDressAlteration } },
      },
      {
        '@type': 'FAQPage',
        mainEntity: FAQ.map(([q, a]) => ({ '@type': 'Question', name: q, acceptedAnswer: { '@type': 'Answer', text: a } })),
      },
      breadcrumbLd([
        { name: 'Terzi Can', url: `${SITE_URL}/terzi` },
        { name: 'Gelinlik Tadilatı', url: PAGE_URL },
      ]),
      { '@type': 'WebPage', '@id': `${PAGE_URL}#webpage`, url: PAGE_URL, name: TITLE, inLanguage: 'tr', about: { '@id': BUSINESS_ID } },
    ],
  }

  const card = { background: '#fff', border: '1px solid #E7DFD2', borderRadius: 14, padding: '1.1rem 1.2rem' } as const
  return (
    <main style={{ maxWidth: 880, margin: '0 auto', padding: '2rem 1.2rem 6rem', color: '#1C1814', lineHeight: 1.7 }}>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: ldJson(ld) }} />
      <nav aria-label="breadcrumb" style={{ fontSize: '.8rem', marginBottom: '1rem' }}>
        <Link href="/terzi">Terzi Can</Link> › Gelinlik Tadilatı
      </nav>

      <h1 style={{ fontSize: 'clamp(1.8rem,5vw,2.6rem)', lineHeight: 1.15, margin: '0 0 .6rem' }}>Gelinlik Tadilatı Antalya — Konyaaltı</h1>
      <p style={{ fontSize: '1.05rem' }}>
        Terzi Can, Konyaaltı Hurma Mahallesi&apos;ndeki atölyesinde gelinlik, abiye ve damatlık tadilatı yapar.
        Fiyatlar <strong>{PRICES.weddingDressAlteration} ₺&apos;den</strong> başlar. {HOURS.text.tr}.
      </p>
      <p style={{ display: 'flex', gap: '.6rem', flexWrap: 'wrap' }}>
        <a href={waLink('Merhaba, gelinlik tadilatı için fiyat ve randevu almak istiyorum.')} style={{ background: '#25D366', color: '#fff', padding: '.7rem 1.2rem', borderRadius: 999, textDecoration: 'none', fontWeight: 700 }}>💬 WhatsApp ile fiyat al</a>
        <a href={GBP.directionsUrl} style={{ background: '#1C1814', color: '#fff', padding: '.7rem 1.2rem', borderRadius: 999, textDecoration: 'none', fontWeight: 700 }}>🧭 Yol tarifi</a>
      </p>

      <h2 style={{ marginTop: '2rem' }}>Yaptığımız gelinlik işlemleri</h2>
      <div style={{ display: 'grid', gap: '.8rem', gridTemplateColumns: 'repeat(auto-fit,minmax(250px,1fr))' }}>
        {SERVICES.map(([t, d]) => (
          <div key={t} style={card}><strong>{t}</strong><p style={{ margin: '.3rem 0 0', fontSize: '.92rem' }}>{d}</p></div>
        ))}
      </div>

      <h2 style={{ marginTop: '2rem' }}>Nasıl çalışıyoruz?</h2>
      <ol>
        <li>Gelinliğin fotoğrafını ve yapılacak işlemi WhatsApp&apos;tan gönderin; fiyat bilgisi verelim.</li>
        <li>Atölyemizde prova yapılır, ölçüler alınır (isterseniz adrese veya otele geliriz).</li>
        <li>Tadilat tamamlanır, son prova ile teslim edilir.</li>
      </ol>

      <h2 style={{ marginTop: '2rem' }}>Sık sorulan sorular</h2>
      {FAQ.map(([q, a]) => (
        <details key={q} style={{ ...card, marginBottom: '.6rem' }}>
          <summary style={{ fontWeight: 700, cursor: 'pointer' }}>{q}</summary>
          <p style={{ margin: '.5rem 0 0' }}>{a}</p>
        </details>
      ))}

      <h2 style={{ marginTop: '2rem' }}>Adres ve saatler</h2>
      <p>
        {BRAND.gbpName} — {ADDRESS.oneLine}<br />
        {HOURS.text.tr} · <a href={`tel:${PHONE.replace(/\s/g, '')}`}>{PHONE}</a>
      </p>
      <p style={{ fontSize: '.9rem' }}>
        Diğer hizmetler: <Link href="/terzi/paca-kisaltma-antalya">paça kısaltma</Link> · <Link href="/terzi/fermuar-degisimi">fermuar değişimi</Link> ·{' '}
        <Link href="/terzi/bayan-terzi-antalya">bayan terzi</Link> · <Link href="/terzi/eve-gelen-terzi-antalya">eve gelen terzi</Link> ·{' '}
        <Link href="/terzi/kuru-temizleme-antalya">kuru temizleme</Link>
      </p>
    </main>
  )
}
