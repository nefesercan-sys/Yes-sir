import { NextResponse } from 'next/server'
import { ANTALYA_ILCELERI, KONYAALTI_MAHALLELERI } from '@/lib/turkiye-lokasyonlar'
import { OTEL_BOLGELERI } from '@/lib/otel-bolgeleri'
import {
  SITE_URL, CLUSTER_LOCAL, CLUSTER_ONLINE, CLUSTER_ATELIER, regionLanguages,
} from '@/lib/terzi-business'

export const revalidate = 86400

// lastmod: sayfa içeriğini GERÇEKTEN güncellediğinizde ilgili tarihi değiştirin.
// (Hepsine aynı tarih vermek Google'ın lastmod'u güvenilmez bulmasına yol açar.)
const LM = {
  core: '2026-10-03',   // saat/adres/şema düzeltmesi yapılan ana sayfalar
  other: '2026-10-02',
} as const

type Alt = Record<string, string>
type Entry = { url: string; lastmod: string; priority: string; freq: string; alt?: Alt }

const path = (u: string) => u.replace(SITE_URL, '')
const altOf = (c: Record<string, string>): Alt => c
const clusterFor = (url: string): Alt | undefined => {
  for (const c of [CLUSTER_LOCAL, CLUSTER_ONLINE, CLUSTER_ATELIER] as Record<string, string>[]) {
    if (Object.values(c).includes(url)) return c
  }
  return undefined
}

export async function GET() {
  const B = SITE_URL
  const core = (p: string, priority: string, freq = 'weekly'): Entry => {
    const url = `${B}${p}`
    return { url, lastmod: LM.core, priority, freq, alt: clusterFor(url) }
  }

  const entries: Entry[] = [
    // 1) Ana odak
    core('/terzi', '1.0', 'daily'),
    core('/online-tailor-service', '0.95', 'weekly'),
    core('/terzi/eve-gelen-terzi-antalya', '0.95'),
    core('/terzi/gelinlik-tadilati', '0.90'),

    // 2) Yüksek trafikli Türkçe landing sayfaları
    core('/antalya-konyaalti-terzi-elbise-dikim-tadilat-utu-hizmeti', '0.95'),
    core('/antalya-konyaalti-terzi-elbise-dikim-tamir-tadilat', '0.90'),
    core('/antalya-terzi-dikim-utu-kuru-temizleme-tekstil-imalat', '0.90'),
    core('/antalya-terzi-elbise-dikimi', '0.90'),
    core('/antalyada-terzi-dikim-tamirat-utu-hizmetleri', '0.90'),

    // 3) Mikro hizmet sayfaları
    core('/online-terzi-hizmeti', '0.90'),
    core('/terzi/paca-kisaltma-antalya', '0.90'),
    core('/terzi/bay-terzi-antalya', '0.90'),
    core('/terzi/bayan-terzi-antalya', '0.90'),
    core('/terzi/fermuar-degisimi', '0.90'),
    core('/terzi/uniforma-uretimi-antalya', '0.80'),
    core('/terzi/kuru-temizleme-antalya', '0.80'),
    core('/terzi/dikis-atolyesi-antalya', '0.80'),

    // 4) Çok dilli sayfalar (hreflang karşılıklı)
    core('/en/hotel-tailor-antalya', '0.90'),
    core('/de/schneider-service-hotel-antalya', '0.90'),
    core('/ru/vyezdnoy-portnoy-antalya', '0.90'),
    core('/de/online-schneiderservice-antalya', '0.85'),
    core('/ru/atelie-antalya-online', '0.85'),
    core('/ru/atelie-antalya', '0.85'),

    // 5) Dönüşüm sayfaları
    core('/terzi-cagir', '0.60', 'monthly'),
  ]

  // Yerel SEO — Konyaaltı mahalleleri ve Antalya ilçeleri
  KONYAALTI_MAHALLELERI.forEach((m) =>
    entries.push({ url: `${B}/terzi/konyaalti/${m.slug}`, lastmod: LM.other, priority: '0.85', freq: 'weekly' }),
  )
  ANTALYA_ILCELERI.filter((i) => i.slug !== 'konyaalti').forEach((i) =>
    entries.push({ url: `${B}/terzi/antalya/${i.slug}`, lastmod: LM.other, priority: '0.80', freq: 'weekly' }),
  )

  // Otel bölgeleri: slug listesi veri dosyasından gelir (var olmayan slug 404 vermesin)
  OTEL_BOLGELERI.forEach(({ slug }) => {
    const alt = regionLanguages(slug) as Alt
    ;(['en', 'ru', 'de'] as const).forEach((l) =>
      entries.push({ url: alt[l], lastmod: LM.other, priority: '0.80', freq: 'weekly', alt }),
    )
  })

  const esc = (s: string) => s.replace(/&/g, '&amp;')
  const links = (alt?: Alt) =>
    alt
      ? Object.entries(alt)
          .map(([hl, href]) => `    <xhtml:link rel="alternate" hreflang="${hl}" href="${esc(href)}"/>`)
          .join('\n') + '\n'
      : ''

  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${entries
  .map(
    (e) => `  <url>
    <loc>${esc(e.url)}</loc>
    <lastmod>${e.lastmod}</lastmod>
${links(e.alt)}  </url>`,
  )
  .join('\n')}
</urlset>`

  return new NextResponse(xml, {
    headers: {
      'Content-Type': 'application/xml; charset=utf-8',
      'Cache-Control': 'public, s-maxage=86400, stale-while-revalidate=43200',
    },
  })
}
