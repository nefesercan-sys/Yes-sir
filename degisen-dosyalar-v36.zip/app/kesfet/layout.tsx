import type { Metadata } from 'next'
import { SITE_URL } from '@/lib/terzi-business'

export const metadata: Metadata = {
  title: { absolute: 'Keşfet — Hizmet ve Ürün İlanları | SwapHubs' },
  description: 'SwapHubs üzerinde hizmet ve ürün ilanlarını keşfedin. Terzi hizmetleri için Terzi Can sayfasına gidin.',
  alternates: { canonical: `${SITE_URL}/kesfet` },
  robots: { index: false, follow: true },
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
