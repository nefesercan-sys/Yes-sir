import type { Metadata } from 'next'
import { SITE_URL, OG_IMAGE, PHONE } from '@/lib/terzi-business'

export const metadata: Metadata = {
  title: { absolute: 'Terzi Talep Formu — Antalya Konyaaltı | Terzi Can' },
  description: `Terzi talebinizi iletin: tadilat, dikim, paça kısaltma, eve veya otele gelen terzi. Her gün 08:00–23:00. WhatsApp: ${PHONE}`,
  alternates: { canonical: `${SITE_URL}/terzi-talep` },
  openGraph: { title: 'Terzi Talep Formu — Terzi Can Antalya', url: `${SITE_URL}/terzi-talep`, siteName: 'Terzi Can', images: [OG_IMAGE], locale: 'tr_TR', type: 'website' },
  robots: { index: true, follow: true },
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
