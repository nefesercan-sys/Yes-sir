import type { Metadata } from 'next'
import { SITE_URL } from '@/lib/terzi-business'

export const metadata: Metadata = {
  title: { absolute: 'Hizmet ve Ürün İlanları | SwapHubs' },
  description: 'Türkiye genelinde hizmet ve ürün ilanları. Terzi hizmetleri için Terzi Can sayfasına bakın.',
  alternates: { canonical: `${SITE_URL}/ilanlar` },
  robots: { index: true, follow: true },
}

export default function Layout({ children }: { children: React.ReactNode }) {
  return <>{children}</>
}
