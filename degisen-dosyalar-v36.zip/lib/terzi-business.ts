// lib/terzi-business.ts
// ─────────────────────────────────────────────────────────────────────────────
// TEK DOĞRULUK KAYNAĞI — Terzi Can (Konyaaltı, Hurma Mahallesi / Antalya)
//
// Telefon, adres, saat, GBP linki, fiyat ve hreflang kümeleri SADECE burada
// tanımlanır. Bir bilgi değişecekse yalnızca bu dosyayı düzenleyin.
// Farklı sayfalarda farklı adres/saat/telefon görmek Google'a ve yapay zekâ
// botlarına "bunlar farklı işletmeler" sinyali verir (NAP tutarsızlığı).
// ─────────────────────────────────────────────────────────────────────────────

export const SITE_URL = 'https://swaphubs.com'

// Marka: ön planda Terzi Can. SwapHubs yalnızca üst platform.
export const BRAND = {
  name: 'Terzi Can',
  gbpName: 'TERZİ Can Antalya Tailor Service', // GBP'deki işletme adıyla birebir aynı olmalı
  alternateNames: [
    'Terzi Can Antalya',
    'Konyaaltı Terzi Can',
    'Tailor Can Antalya',
    'Портной Кан Анталья',
    'Schneider Can Antalya',
  ],
  parent: { name: 'SwapHubs', url: SITE_URL },
} as const

// ── İletişim (TEK telefon) ───────────────────────────────────────────────────
export const PHONE = '+90 531 898 64 18'
export const PHONE_E164 = '+905318986418'
export const WA_NUMBER = '905318986418'
export const waLink = (msg = '') =>
  `https://wa.me/${WA_NUMBER}${msg ? `?text=${encodeURIComponent(msg)}` : ''}`

// ── Adres (TEK adres: Konyaaltı, Hurma Mahallesi) ────────────────────────────
// streetAddress: GBP'de cadde/kapı no varsa buraya ekleyin ("Hurma Mahallesi, 37. Cadde No:50" gibi).
export const ADDRESS = {
  streetAddress: 'Hurma Mahallesi',
  addressLocality: 'Konyaaltı',
  addressRegion: 'Antalya',
  postalCode: '07130',
  addressCountry: 'TR',
  oneLine: 'Hurma Mahallesi, 07130 Konyaaltı / Antalya',
} as const

// ── Koordinat: Konyaaltı, Hurma Mahallesi ────────────────────────────────────
// Kaynak: Yandex Maps "Hurma Mah., Konyaaltı" (36.858627, 30.603554); Vikipedi
// 36.86149, 30.60202 ile uyumlu. Bu MAHALLE merkezidir (adreste cadde/kapı no yok).
// Tam pin için: Google Maps'te işletme pinine sağ tık → ilk satırdaki değeri buraya yazın.
// Tüm sayfalardaki JSON-LD `geo` alanı otomatik buradan gelir.
export const GEO = { latitude: 36.858627, longitude: 30.603554 } as { latitude: number; longitude: number } | null

export const geoLd = () =>
  GEO ? { geo: { '@type': 'GeoCoordinates', latitude: GEO.latitude, longitude: GEO.longitude } } : {}

// ── Google Business Profile (TEK profil) ─────────────────────────────────────
// Kopya profilleri (Konyaaltı Terzi, ANTALYA TERZİ CAN - TAILOR vb.) GBP
// panelinden birleştirin/kapatın. Kodda artık yalnızca bu profil kullanılır.
// İsteğe bağlı: placeId alanına "ChIJ..." biçimli Place ID'yi yazarsanız
// yorum/yol tarifi linkleri doğrudan profile gider.
export const GBP = {
  shareUrl: 'https://share.google/ppkxQGTVWahWAmDpg',
  placeId: '' as string,
  get directionsUrl() {
    return this.placeId
      ? `https://www.google.com/maps/dir/?api=1&destination=Terzi+Can+Konyaalti+Hurma+Antalya&destination_place_id=${this.placeId}`
      : 'https://www.google.com/maps/dir/?api=1&destination=Terzi+Can+Konyaalti+Hurma+Antalya'
  },
  get reviewUrl() {
    return this.placeId
      ? `https://search.google.com/local/writereview?placeid=${this.placeId}`
      : 'https://share.google/ppkxQGTVWahWAmDpg'
  },
  embedUrl: 'https://www.google.com/maps?q=TERZ%C4%B0+Can+Antalya+Tailor+Service&output=embed',
}

// ── Çalışma saatleri (TEK tanım): haftanın her günü 08:00–23:00 ───────────────
export const HOURS = {
  days: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'] as const,
  opens: '08:00',
  closes: '23:00',
  text: {
    tr: 'Haftanın her günü 08:00–23:00',
    en: 'Every day 08:00–23:00',
    ru: 'Ежедневно 08:00–23:00',
    de: 'Täglich 08:00–23:00',
  },
} as const

export const openingHoursSpec = () => [
  {
    '@type': 'OpeningHoursSpecification',
    dayOfWeek: [...HOURS.days],
    opens: HOURS.opens,
    closes: HOURS.closes,
  },
]

// ── Fiyatlar (TL, başlangıç) ─────────────────────────────────────────────────
// Eve/otele gelen servis: ziyaret ÜCRETSİZ, yalnızca yapılan iş ücretlendirilir.
export const PRICES = {
  hemming: 150,
  zipper: 200,
  waist: 150,
  dress: 800,
  weddingDressAlteration: 500,
  dryCleaning: 300,
  ironing: 80,
  uniform: 1000,
  visit: 0,
} as const

// Hizmet bölgesi: ANTALYA'NIN TÜM İLÇELERİ ve turistik bölgeler (eve/otele gelen servis);
// online hizmet ise Türkiye geneli. Atölye adresi Konyaaltı, Hurma Mahallesi.
export const SERVICE_AREAS = [
  'Konyaaltı', 'Muratpaşa', 'Kepez', 'Döşemealtı', 'Aksu',
  'Lara', 'Kundu', 'Güzeloba', 'Belek', 'Kadriye', 'Kemer', 'Çamyuva', 'Tekirova',
  'Side', 'Manavgat', 'Serik', 'Alanya', 'Mahmutlar', 'Kaş', 'Kalkan', 'Kumluca', 'Finike', 'Demre', 'Gazipaşa',
] as const

// areaServed: il + ilçeler (AdministrativeArea) ve Türkiye (online sipariş/kargo)
export const areaServedLd = () => [
  { '@type': 'AdministrativeArea', name: 'Antalya' },
  ...SERVICE_AREAS.map((name) => ({ '@type': 'City', name })),
  { '@type': 'Country', name: 'Türkiye' },
]

export const LANGUAGES = ['tr', 'en', 'ru', 'de'] as const

// ── Görseller (public/ içinde GERÇEKTEN var olan dosyalar) ───────────────────
export const OG_IMAGE = `${SITE_URL}/og/terzi-can.jpg`
export const LOGO = `${SITE_URL}/og/logo.png`

// ── Doğrulanmış profiller (sameAs) — sadece GERÇEK hesaplar ──────────────────
// Instagram / Facebook / Bing Places / Apple Business Connect / Yandex Business
// URL'lerinizi buraya ekleyin.
export const SAME_AS: string[] = [
  GBP.shareUrl,
  // 'https://www.instagram.com/<hesap>',
  // 'https://www.facebook.com/<sayfa>',
]

export const BUSINESS_ID = `${SITE_URL}/terzi#business`

// ── hreflang kümeleri (karşılıklı olmak ZORUNDA) ─────────────────────────────
export const CLUSTER_LOCAL = {
  tr: `${SITE_URL}/terzi/eve-gelen-terzi-antalya`,
  en: `${SITE_URL}/en/hotel-tailor-antalya`,
  ru: `${SITE_URL}/ru/vyezdnoy-portnoy-antalya`,
  de: `${SITE_URL}/de/schneider-service-hotel-antalya`,
  'x-default': `${SITE_URL}/en/hotel-tailor-antalya`,
} as const

export const CLUSTER_ONLINE = {
  tr: `${SITE_URL}/online-terzi-hizmeti`,
  en: `${SITE_URL}/online-tailor-service`,
  ru: `${SITE_URL}/ru/atelie-antalya-online`,
  de: `${SITE_URL}/de/online-schneiderservice-antalya`,
  'x-default': `${SITE_URL}/online-terzi-hizmeti`,
} as const

// Ana sayfa (TR) ↔ RU atölye sayfası
export const CLUSTER_ATELIER = {
  tr: `${SITE_URL}/terzi`,
  ru: `${SITE_URL}/ru/atelie-antalya`,
  'x-default': `${SITE_URL}/terzi`,
} as const

// Bölge sayfaları (belek, lara, kemer…): EN/RU/DE karşılıklı küme.
// (Türkçe karşılığı yok: /terzi/antalya/[ilce] ayrı niyet taşıyan yerel sayfa.)
export const regionLanguages = (slug: string) => ({
  en: `${SITE_URL}/en/hotel-tailor-antalya/${slug}`,
  ru: `${SITE_URL}/ru/vyezdnoy-portnoy-antalya/${slug}`,
  de: `${SITE_URL}/de/schneider-service-hotel-antalya/${slug}`,
  'x-default': `${SITE_URL}/en/hotel-tailor-antalya/${slug}`,
})

// ── Ortak JSON-LD: tek LocalBusiness varlığı ─────────────────────────────────
export function localBusinessLd(opts: { description: string; url?: string }) {
  return {
    '@type': ['LocalBusiness', 'ClothingStore', 'DryCleaningOrLaundry'],
    '@id': BUSINESS_ID,
    name: BRAND.name,
    alternateName: [BRAND.gbpName, ...BRAND.alternateNames],
    description: opts.description,
    url: opts.url ?? `${SITE_URL}/terzi`,
    telephone: PHONE_E164,
    priceRange: '₺₺',
    currenciesAccepted: 'TRY, EUR, USD, RUB',
    paymentAccepted: 'Cash, Credit Card',
    knowsLanguage: [...LANGUAGES],
    image: [OG_IMAGE],
    logo: LOGO,
    parentOrganization: { '@type': 'Organization', ...BRAND.parent },
    address: { '@type': 'PostalAddress', ...ADDRESS },
    ...geoLd(),
    hasMap: GBP.shareUrl,
    sameAs: SAME_AS,
    openingHoursSpecification: openingHoursSpec(),
    areaServed: areaServedLd(),
    contactPoint: [
      {
        '@type': 'ContactPoint',
        telephone: PHONE_E164,
        contactType: 'customer service',
        availableLanguage: ['Turkish', 'English', 'Russian', 'German'],
      },
    ],
  }
}

export const businessRef = () => ({ '@id': BUSINESS_ID })

export function breadcrumbLd(items: { name: string; url: string }[]) {
  return {
    '@type': 'BreadcrumbList',
    itemListElement: items.map((it, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: it.name,
      item: it.url,
    })),
  }
}

export const ldJson = (data: unknown) => JSON.stringify(data).replace(/</g, '\\u003c')
