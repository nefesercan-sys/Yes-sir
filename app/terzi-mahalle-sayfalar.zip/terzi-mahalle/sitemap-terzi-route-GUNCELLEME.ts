// app/sitemap-terzi.xml/route.ts içinde terziSayfalar dizisine ekleyin:
// Mevcut son satırdan ÖNCE şunları ekleyin:

  // ── Konyaaltı Mahalle Sayfaları ──────────────────────────────────────────
  { url: `${BASE}/terzi/konyaalti-terzi`,      priority: "0.95", freq: "weekly" },
  { url: `${BASE}/terzi/liman-terzi`,          priority: "0.9",  freq: "weekly" },
  { url: `${BASE}/terzi/hurma-terzi`,          priority: "0.9",  freq: "weekly" },
  { url: `${BASE}/terzi/sarisu-terzi`,         priority: "0.9",  freq: "weekly" },
  { url: `${BASE}/terzi/uncali-terzi`,         priority: "0.9",  freq: "weekly" },
  { url: `${BASE}/terzi/gursu-terzi`,          priority: "0.9",  freq: "weekly" },
  { url: `${BASE}/terzi/ogretmenevleri-terzi`, priority: "0.9",  freq: "weekly" },
  { url: `${BASE}/terzi/meltem-terzi`,         priority: "0.9",  freq: "weekly" },
  { url: `${BASE}/terzi/cakirlar-terzi`,       priority: "0.9",  freq: "weekly" },
